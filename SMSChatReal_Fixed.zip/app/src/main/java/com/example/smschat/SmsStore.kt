package com.example.smschat

import android.content.ContentValues
import android.content.Context
import android.provider.Telephony

data class SmsRow(
    val id: Long,
    val address: String,
    val body: String,
    val date: Long,
    val type: Int
)

object SmsStore {

    fun loadConversation(context: Context, address: String): List<SmsRow> {
        val result = mutableListOf<SmsRow>()
        val projection = arrayOf(
            Telephony.Sms._ID,
            Telephony.Sms.ADDRESS,
            Telephony.Sms.BODY,
            Telephony.Sms.DATE,
            Telephony.Sms.TYPE
        )

        val cursor = context.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            projection,
            "${Telephony.Sms.ADDRESS} = ?",
            arrayOf(address),
            "${Telephony.Sms.DATE} ASC"
        ) ?: return result

        cursor.use {
            val id = it.getColumnIndexOrThrow(Telephony.Sms._ID)
            val addr = it.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)
            val body = it.getColumnIndexOrThrow(Telephony.Sms.BODY)
            val date = it.getColumnIndexOrThrow(Telephony.Sms.DATE)
            val type = it.getColumnIndexOrThrow(Telephony.Sms.TYPE)

            while (it.moveToNext()) {
                result += SmsRow(
                    it.getLong(id),
                    it.getString(addr) ?: address,
                    it.getString(body) ?: "",
                    it.getLong(date),
                    it.getInt(type)
                )
            }
        }
        return result
    }

    fun insertSent(context: Context, address: String, body: String) {
        val values = ContentValues().apply {
            put(Telephony.Sms.ADDRESS, address)
            put(Telephony.Sms.BODY, body)
            put(Telephony.Sms.DATE, System.currentTimeMillis())
            put(Telephony.Sms.READ, 1)
            put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_SENT)
        }
        context.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, values)
    }
}
