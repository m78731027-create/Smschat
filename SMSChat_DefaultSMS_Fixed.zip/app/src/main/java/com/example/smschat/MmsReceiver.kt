package com.example.smschat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Receives WAP Push/MMS delivery broadcasts.
 *
 * The intent filter is required so Android can recognize this application
 * as eligible for the default SMS role. Full MMS parsing/storage can be
 * implemented later.
 */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.provider.Telephony.WAP_PUSH_DELIVER") return
        // Reserved for MMS/WAP-PUSH handling.
    }
}
