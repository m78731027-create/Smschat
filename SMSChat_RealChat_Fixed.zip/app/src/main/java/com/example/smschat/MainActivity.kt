package com.example.smschat

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.database.ContentObserver
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.PhoneNumberUtils
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF050B14)
private val Panel = Color(0xFF111D31)
private val Panel2 = Color(0xFF182640)
private val Blue = Color(0xFF1677FF)
private val Blue2 = Color(0xFF315CFF)
private val TextMain = Color(0xFFF4F7FF)
private val TextMuted = Color(0xFF91A4C6)

private const val CONTACT = "09156285665"
private const val CONTACT_NAME = "علی رضایی"

class MainActivity : ComponentActivity() {

    private var refreshTick by mutableIntStateOf(0)
    private var defaultSmsState by mutableStateOf(false)
    private lateinit var smsObserver: ContentObserver

    private val smsPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            refreshTick++
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            defaultSmsState = isDefaultSmsApp()
            if (defaultSmsState) {
                requestRuntimePermissions()
            }
            refreshTick++
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        defaultSmsState = isDefaultSmsApp()
        NotificationHelper.createChannel(this)

        smsObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                refreshTick++
            }
        }
        contentResolver.registerContentObserver(Telephony.Sms.CONTENT_URI, true, smsObserver)

        setContent {
            SmsChatScreen(
                isDefaultSms = defaultSmsState,
                onMakeDefault = { requestDefaultSmsApp() },
                onRequestPermissions = { requestRuntimePermissions() },
                onRefresh = { refreshTick++ },
                refreshTick = refreshTick
            )
        }

        // Notification permission is independent of SMS role.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        defaultSmsState = isDefaultSmsApp()
        refreshTick++
    }

    override fun onDestroy() {
        if (::smsObserver.isInitialized) {
            contentResolver.unregisterContentObserver(smsObserver)
        }
        super.onDestroy()
    }

    private fun requestRuntimePermissions() {
        val permissions = mutableListOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS
        )
        smsPermissionLauncher.launch(permissions.toTypedArray())
    }

    private fun isDefaultSmsApp(): Boolean =
        Telephony.Sms.getDefaultSmsPackage(this) == packageName

    private fun requestDefaultSmsApp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_SMS)) {
                roleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS))
            }
        } else {
            val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
            roleLauncher.launch(intent)
        }
    }
}

@Composable
private fun SmsChatScreen(
    isDefaultSms: Boolean,
    onMakeDefault: () -> Unit,
    onRequestPermissions: () -> Unit,
    onRefresh: () -> Unit,
    refreshTick: Int
) {
    var contactExpanded by remember { mutableStateOf(false) }
    var composerExpanded by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf(TextFieldValue("")) }
    var muted by remember { mutableStateOf(false) }
    var blocked by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val hasReadPermission = ActivityCompat.checkSelfPermission(
        context, Manifest.permission.READ_SMS
    ) == PackageManager.PERMISSION_GRANTED

    val messages = remember(hasReadPermission, isDefaultSms, refreshTick) {
        if (hasReadPermission) SmsStore.loadConversation(context, CONTACT) else emptyList()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF07101C), Bg, Color(0xFF030810))))
        ) {
            Column(Modifier.fillMaxSize()) {

                Spacer(Modifier.height(10.dp))

                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RoundAction(Icons.Default.ArrowBack, Modifier.size(58.dp)) { }

                    Spacer(Modifier.width(10.dp))

                    Box(
                        Modifier
                            .weight(1f)
                            .height(76.dp)
                            .clip(RoundedCornerShape(40.dp))
                            .background(Brush.horizontalGradient(listOf(Color(0xFF14233C), Color(0xFF0D1A2D))))
                            .clickable { contactExpanded = !contactExpanded }
                            .padding(horizontal = 18.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(CONTACT_NAME, color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                                Text(CONTACT, color = TextMuted, fontSize = 13.sp)
                            }
                            Spacer(Modifier.width(28.dp))
                            Avatar()
                        }
                    }

                    Spacer(Modifier.width(10.dp))
                    RoundAction(Icons.Default.Call, Modifier.size(58.dp)) { }
                }

                AnimatedVisibility(
                    visible = contactExpanded,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    ContactPanel(
                        muted, blocked,
                        onMute = { muted = !muted },
                        onBlock = { blocked = !blocked },
                        onDelete = { contactExpanded = false }
                    )
                }

                if (!isDefaultSms) {
                    DefaultSmsBanner(onMakeDefault)
                } else if (!hasReadPermission) {
                    PermissionBanner(onRequestPermissions)
                }

                Box(Modifier.weight(1f).fillMaxWidth()) {
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        reverseLayout = true,
                        contentPadding = PaddingValues(18.dp, 12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (messages.isEmpty()) {
                            item {
                                Box(Modifier.fillMaxWidth().padding(top = 28.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        if (hasReadPermission) "هنوز پیامکی با این مخاطب پیدا نشد" else "برای نمایش پیامک‌های واقعی، مجوز پیامک را فعال کنید",
                                        color = TextMuted,
                                        fontSize = 14.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                        items(messages.asReversed()) { row ->
                            MessageBubble(
                                text = row.body,
                                time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(row.date)),
                                mine = row.type == Telephony.Sms.MESSAGE_TYPE_SENT ||
                                       row.type == Telephony.Sms.MESSAGE_TYPE_OUTBOX
                            )
                        }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                                Text(
                                    "היום",
                                    color = TextMuted,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(Panel2)
                                        .padding(horizontal = 18.dp, vertical = 8.dp),
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }

                Composer(
                    expanded = composerExpanded,
                    value = text,
                    onValueChange = { text = it },
                    onExpand = { composerExpanded = !composerExpanded },
                    onSend = {
                        val body = text.text.trim()
                        if (body.isNotEmpty()) {
                            sendSms(context, CONTACT, body, isDefaultSms)
                            text = TextFieldValue("")
                            composerExpanded = false
                            onRefresh()
                        }
                    },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }
        }
    }
}

private fun sendSms(context: Context, address: String, body: String, isDefaultSms: Boolean) {
    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
        return
    }

    runCatching {
        SmsManager.getDefault().sendTextMessage(address, null, body, null, null)
        if (isDefaultSms) {
            SmsStore.insertSent(context, address, body)
        }
    }
}

@Composable
private fun DefaultSmsBanner(onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF122544))
            .clickable { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Sms, null, tint = Blue)
        Spacer(Modifier.width(10.dp))
        Text("برای ارسال و دریافت واقعی، این برنامه را SMS پیش‌فرض کنید", color = TextMain, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text("فعال‌سازی", color = Color(0xFF7FB2FF), fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
private fun PermissionBanner(onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF122544))
            .clickable { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Security, null, tint = Blue)
        Spacer(Modifier.width(10.dp))
        Text("مجوزهای پیامک برای خواندن تاریخچه لازم است", color = TextMain, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text("اجازه", color = Color(0xFF7FB2FF), fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
private fun ContactPanel(
    muted: Boolean,
    blocked: Boolean,
    onMute: () -> Unit,
    onBlock: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF13213A), Color(0xFF0D182A))))
            .padding(vertical = 18.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        ContactAction(Icons.Default.Share, "اشتراک مخاطب") { }
        ContactAction(if (blocked) Icons.Default.CheckCircle else Icons.Default.Block,
            if (blocked) "رفع مسدودیت" else "مسدود کردن", onBlock)
        ContactAction(Icons.Default.DeleteOutline, "حذف مکالمه", onDelete)
        ContactAction(if (muted) Icons.Default.NotificationsOff else Icons.Default.Notifications,
            if (muted) "اعلان‌ها خاموش" else "اعلان‌ها", onMute)
    }
}

@Composable
private fun ContactAction(icon: ImageVector, title: String, onClick: () -> Unit) {
    Column(Modifier.width(88.dp).clickable { onClick() }, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(Panel2), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = TextMain, modifier = Modifier.size(25.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(title, color = TextMain, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun MessageBubble(text: String, time: String, mine: Boolean) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End
    ) {
        Box(
            Modifier
                .widthIn(max = 290.dp)
                .clip(RoundedCornerShape(
                    topStart = 22.dp, topEnd = 22.dp,
                    bottomStart = if (mine) 22.dp else 5.dp,
                    bottomEnd = if (mine) 5.dp else 22.dp
                ))
                .background(if (mine) Blue else Panel2)
                .padding(horizontal = 16.dp, vertical = 11.dp)
        ) {
            Column(horizontalAlignment = Alignment.End) {
                Text(text, color = Color.White, fontSize = 16.sp, lineHeight = 24.sp)
                Spacer(Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(time, color = Color(0xFFB9C9E8), fontSize = 11.sp)
                    if (mine) {
                        Spacer(Modifier.width(5.dp))
                        Icon(Icons.Default.DoneAll, null, tint = Color.White, modifier = Modifier.size(15.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun Composer(
    expanded: Boolean,
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    onExpand: () -> Unit,
    onSend: () -> Unit,
    modifier: Modifier
) {
    val height by animateDpAsState(if (expanded) 62.dp else 62.dp, label = "composerHeight")

    Column(modifier.fillMaxWidth()) {
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                AttachmentAction(Icons.Default.Image, "گالری")
                AttachmentAction(Icons.Default.CameraAlt, "دوربین")
                AttachmentAction(Icons.Default.InsertDriveFile, "فایل")
                AttachmentAction(Icons.Default.LocationOn, "موقعیت")
            }
        }

        Row(Modifier.fillMaxWidth().height(height), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(58.dp).clip(CircleShape).background(Blue).clickable { onExpand() },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (expanded) Icons.Default.Close else Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(28.dp))
            }

            Spacer(Modifier.width(8.dp))

            Row(
                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(32.dp))
                    .border(1.dp, Color(0xFF233756), RoundedCornerShape(32.dp))
                    .background(Panel).padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.EmojiEmotions, null, tint = TextMuted)
                Spacer(Modifier.width(10.dp))
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    Modifier.weight(1f),
                    textStyle = TextStyle(color = TextMain, fontSize = 16.sp, textAlign = TextAlign.Right),
                    singleLine = true,
                    decorationBox = { inner ->
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                            if (value.text.isEmpty()) Text("پیام بنویسید", color = TextMuted, fontSize = 16.sp)
                            inner()
                        }
                    }
                )
                Spacer(Modifier.width(10.dp))
                Icon(Icons.Default.AttachFile, null, tint = TextMuted)
            }

            Spacer(Modifier.width(8.dp))

            Box(
                Modifier.size(58.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Blue, Blue2)))
                    .clickable { if (value.text.isNotBlank()) onSend() },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (value.text.isBlank()) Icons.Default.CameraAlt else Icons.Default.Send,
                    null, tint = Color.White, modifier = Modifier.size(27.dp))
            }
        }
    }
}

@Composable
private fun AttachmentAction(icon: ImageVector, title: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(72.dp)) {
        Box(Modifier.size(45.dp).clip(CircleShape).background(Panel2), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = TextMain)
        }
        Spacer(Modifier.height(4.dp))
        Text(title, color = TextMuted, fontSize = 11.sp)
    }
}

@Composable
private fun RoundAction(icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.clip(CircleShape).background(Panel2).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = TextMain, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun Avatar() {
    Box(
        Modifier.size(50.dp).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF5B83C8), Color(0xFF243C69)))),
        contentAlignment = Alignment.Center
    ) {
        Text("ع", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}
